# My Application

## Overview
My Application is a tool that allows users to automate mouse clicks with customizable intervals and hotkeys.

## Installation
1. Download the installer from [link].
2. Run the installer and follow the on-screen instructions.
3. Launch the application from the Start menu or desktop shortcut.

## Usage
- Set your desired click intervals in hours, minutes, seconds, and milliseconds.
- Change the hotkey by clicking the "Change Hotkey" button and pressing the desired key.
- Click "Start" to begin auto-clicking.

## Support
For support or inquiries, please contact [ethan.owsiany@icloud.com].
